// Массивы

// let a = [1,2,3,4,5,'Hello','world',true];
// console.log(a)

// let ar = [[1,2,3],[4,5,6,]];
// console.log(ar);

// Циклы

//  let i = 0
//  while(i < 5){
//      console.log(i);
//      i++;
// }

// let a = 0;

//do
// do{
//     console.log(a);
//     a++;
// }while(a < 6)

//for
// for(let j = 0;j < 10;j++){
//     console.log(j)
// }

//  let arr=[1,2,3,4,6,7]
//  console.log(arr)
//  for(let i = 0; i < arr.length;i++){
//  console.log(arr[2] = "one")
// }

// let arr=[1,2,3,4,5,6,8]
// console.log(arr.length)


//zadanie 1

// let  c=[1,2,3,4,5]
// for(let c = 1;c < 6;c++){
//     alert(c)
// }

//zadanie 2

//  for(let a = 2;a <12;a++)
//  if(a % 2 ==0){
//  console.log(a)
// }

// let b=["Понедельник","Вторник","Среда","Четверг","Пятница","Суббота","Воскресенье"]
// console.log(b)
// for(let i = 0; i < b.length;i++){
//     if(i == 5 || i == 6){
//         console.log(b[i]="weekend")
//     }    
// }

//zadanie 2.1

let a =['Natasha','Anastasia','Dmitry','Maxim']
for(let b = 0;b <a.length;b++){
    if(b == 0){
        a.splice(0,1)
    }
 }
 console.log(a)
 // zadanie 2.2
 for(let num = 0;num <10;num++){
     console.log(1*2,2*2,3*2,4*2,5,6*2,7*2,8*2,9*2,10*2)
}
 //zadanie 2.3

 let Num =[4,6,8,5,12,14]
 for(let i=0;i<Num.length;i++){
     if((Num[i] % 2)==0)
 {console.log(Num[i])}
}

